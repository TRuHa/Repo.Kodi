import xbmcgui
import xbmc, xbmcaddon
import time

monitor = xbmc.Monitor()
addon = xbmcaddon.Addon("service.autofan")
gpio = addon.getSetting('gpio')

#xbmc.log('TEST!!!', level=xbmc.LOGWARNING)

if gpio == 'None':
    addon.openSettings()


def setup_is_good():
    global gpio
    gpio = addon.getSetting('gpio')

    if 'BCM' in gpio:
        return True

    else:
        return False


def load_config():
    global mode, rpm, log
    mode = addon.getSetting('type')
    rpm = addon.getSetting('rpm')
    log = addon.getSetting('log')


def logging(setting):
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())

    h = win.getHeight()
    w = win.getWidth()

    ctrl = xbmcgui.ControlLabel(w / 2, h / 2, 250, 50, setting)
    win.addControl(ctrl)
    time.sleep(1)
    win.removeControl(ctrl)


while not monitor.abortRequested():
    if setup_is_good():
        load_config()
        config = gpio + ':' + mode
        if log == 'true':
            logging(config)
